package ru.garant.liquidtv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.*
import java.net.HttpURLConnection
import java.net.URL

fun norm(s: String): String = s.lowercase().replace("ё", "е").replace("x", "х")
    .replace(Regex("\\(.*?\\)|\\[.*?\\]"), "").replace(Regex("[^\\p{L}\\p{N}]"), "").removeSuffix("hd")

data class Ch(val name: String, val url: String, val logo: String?, val group: String) { val key = norm(name) }

val GROUPS = mapOf("Animation" to "Мультфильмы", "Auto" to "Авто", "Business" to "Бизнес", "Classic" to "Классика",
    "Comedy" to "Юмор", "Cooking" to "Кулинария", "Culture" to "Культура", "Documentary" to "Документальные",
    "Education" to "Образование", "Entertainment" to "Развлекательные", "Family" to "Семейные", "General" to "Общие",
    "Kids" to "Детские", "Legislative" to "Парламентские", "Lifestyle" to "Стиль жизни", "Movies" to "Кино",
    "Music" to "Музыка", "News" to "Новости", "Outdoor" to "Природа и отдых", "Public" to "Общественные",
    "Relax" to "Релакс", "Religious" to "Религия", "Science" to "Наука", "Series" to "Сериалы", "Shop" to "Магазины",
    "Sports" to "Спорт", "Travel" to "Путешествия", "Weather" to "Погода", "Undefined" to "Прочее")
fun ru(g: String) = GROUPS[g] ?: g
val RANK = listOf("Общие", "Новости", "Кино", "Сериалы", "Спорт", "Детские", "Мультфильмы", "Документальные",
    "Наука", "Образование", "Музыка", "Развлекательные", "Юмор", "Культура")
fun rank(g: String) = if (g == "Прочее") 99 else RANK.indexOf(g).let { if (it < 0) 50 else it }

val DEF_FAV = listOf("Первый канал", "Россия 1", "Матч ТВ", "НТВ", "Пятый канал", "Россия К", "Россия 24", "Карусель",
    "ОТР", "ТВ Центр", "РЕН ТВ", "Спас", "СТС", "Домашний", "ТВ-3", "Пятница!", "Звезда", "МИР", "ТНТ", "Муз-ТВ",
    "2х2", "Че!", "Суббота!", "Ю", "РБК", "Известия", "НТВ Право", "Дом кино", "Русский роман", "Русский детектив",
    "Кино ТВ", "Победа", "КХЛ", "Матч! Премьер", "Матч! Игра", "Матч! Арена", "Моя планета", "Наука", "История",
    "Культура", "Живая планета", "TLC", "Discovery Channel", "National Geographic", "Animal Planet", "Eurosport 1",
    "Eurosport 2", "Nickelodeon", "Cartoon Network", "Disney Channel", "В")

const val HUB = "https://iptv-org.github.io/iptv/"
val presets = listOf(
    "Россия" to HUB + "countries/ru.m3u", "Весь мир" to HUB + "index.m3u",
    "Новости" to HUB + "categories/news.m3u", "Кино" to HUB + "categories/movies.m3u",
    "Спорт" to HUB + "categories/sports.m3u"
)

fun fetch(u: String): String {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
    return c.inputStream.bufferedReader().use { it.readText() }
}

fun parse(t: String): List<Ch> {
    val out = mutableListOf<Ch>(); var name = ""; var logo: String? = null; var grp = "Прочее"
    for (l in t.lineSequence().map { it.trim() }) {
        if (l.startsWith("#EXTINF")) {
            name = l.substringAfterLast(",").trim()
            logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1)?.ifBlank { null }
            grp = ru(Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1)?.substringBefore(";")?.ifBlank { null } ?: "Прочее")
        } else if (l.isNotEmpty() && !l.startsWith("#")) {
            if (name.isNotEmpty() && grp != "XXX") out += Ch(name, l, logo, grp); name = ""
        }
    }
    return out
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { App() } }
}

@OptIn(ExperimentalFoundationApi::class, UnstableApi::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val sp = remember { ctx.getSharedPreferences("p", 0) }
    val fm = LocalFocusManager.current
    val fr = remember { FocusRequester() }
    var theme by remember { mutableStateOf(sp.getString("theme", "auto")!!) }
    var lists by remember { mutableStateOf(sp.getString("lists", presets[0].second)!!.split("\n").filter { it.isNotBlank() }) }
    var channels by remember { mutableStateOf(listOf<Ch>()) }
    var status by remember { mutableStateOf("Загрузка…") }
    var favs by remember { mutableStateOf(sp.getString("favl", null)?.split("\n")?.filter { it.isNotBlank() } ?: DEF_FAV.map { norm(it) }) }
    var cur by remember { mutableStateOf<Ch?>(null) }
    var panel by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }
    var grp by remember { mutableStateOf("Избранное") }
    var num by remember { mutableStateOf("") }
    var custom by remember { mutableStateOf("") }

    val ordered = remember(channels, favs) {
        val byKey = channels.associateBy { it.key }
        val fl = favs.mapNotNull { byKey[it] }
        val fs = fl.map { it.key }.toSet()
        fl + channels.filter { it.key !in fs }.sortedWith(compareBy<Ch>({ rank(it.group) }, { it.name.lowercase() }))
    }
    val dark = when (theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val glass = if (dark) Color(0xB31C1C1E) else Color(0xCCF2F2F7)
    val fg = if (dark) Color.White else Color.Black
    val line = fg.copy(alpha = .18f)
    val accent = Color(0xFF0A84FF)
    val shape = RoundedCornerShape(20.dp)

    val player = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(e: PlaybackException) { err = true }
            override fun onPlaybackStateChanged(st: Int) { if (st == Player.STATE_READY) err = false }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }
    LaunchedEffect(lists) {
        status = "Загрузка…"
        channels = withContext(Dispatchers.IO) {
            lists.flatMap { runCatching { parse(fetch(it)) }.getOrDefault(emptyList()) }.distinctBy { it.key }
        }
        status = if (channels.isEmpty()) "Нет каналов. Проверьте ссылку в настройках" else ""
        if (cur == null) { val last = sp.getString("last", null); cur = channels.find { it.url == last } ?: channels.find { it.key in favs } ?: channels.firstOrNull() }
    }
    LaunchedEffect(cur) {
        cur?.let {
            player.setMediaItem(MediaItem.fromUri(it.url)); player.prepare(); player.playWhenReady = true
            sp.edit().putString("last", it.url).apply()
            banner = true; delay(4000); banner = false
        }
    }
    LaunchedEffect(num) {
        if (num.isNotEmpty()) { delay(1800); num.toIntOrNull()?.let { n -> ordered.getOrNull(n - 1)?.let { cur = it } }; num = "" }
    }
    LaunchedEffect(panel, settings) {
        delay(50)
        if (panel || settings) fm.moveFocus(FocusDirection.Enter) else fr.requestFocus()
    }
    BackHandler(enabled = panel || settings) { if (settings) settings = false else panel = false }

    fun step(d: Int) {
        if (ordered.isEmpty()) return
        val i = ordered.indexOf(cur).coerceAtLeast(0)
        cur = ordered[(i + d + ordered.size) % ordered.size]
    }
    fun saveFavs(n: List<String>) { favs = n; sp.edit().putString("favl", n.joinToString("\n")).apply() }
    fun setLists(n: List<String>) { lists = n; sp.edit().putString("lists", n.joinToString("\n")).apply() }
    val digits = listOf(Key.Zero, Key.One, Key.Two, Key.Three, Key.Four, Key.Five, Key.Six, Key.Seven, Key.Eight, Key.Nine)

    @Composable
    fun Glass(m: Modifier, c: @Composable ColumnScope.() -> Unit) =
        Column(m.clip(shape).background(glass).border(1.dp, line, shape).padding(12.dp), content = c)

    @Composable
    fun Item(sel: Boolean, onClick: () -> Unit, onLong: (() -> Unit)? = null, c: @Composable RowScope.() -> Unit) {
        var f by remember { mutableStateOf(false) }
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(12.dp))
            .onFocusChanged { f = it.isFocused }
            .background(if (f) accent else if (sel) fg.copy(alpha = .12f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically, content = c)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)
        .onKeyEvent { e ->
            if (panel || settings || e.type != KeyEventType.KeyDown) false
            else when (e.key) {
                Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> { panel = true; true }
                Key.DirectionUp, Key.ChannelUp -> { step(1); true }
                Key.DirectionDown, Key.ChannelDown -> { step(-1); true }
                Key.Menu -> { settings = true; true }
                else -> { val d = digits.indexOf(e.key); if (d >= 0) { num += d; true } else false }
            }
        }.focusRequester(fr).focusable()) {

        AndroidView(factory = { PlayerView(it).apply { useController = false; isFocusable = false; this.player = player } },
            modifier = Modifier.fillMaxSize())

        if (status.isNotEmpty() || err)
            Text(if (err) "Нет сигнала" else status, color = Color.White, fontSize = 22.sp, modifier = Modifier.align(Alignment.Center))
        if (num.isNotEmpty())
            Text(num, color = Color.White, fontSize = 48.sp, modifier = Modifier.align(Alignment.TopEnd).padding(32.dp))

        if (banner && !panel && cur != null) Glass(Modifier.align(Alignment.BottomCenter).padding(32.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(cur!!.logo, null, Modifier.size(48.dp).padding(end = 12.dp))
                Text("${ordered.indexOf(cur) + 1}  ${cur!!.name}", color = fg, fontSize = 20.sp)
            }
        }

        if (panel) {
            val groups = listOf("Избранное", "Все") + channels.map { it.group }.distinct().sortedWith(compareBy<String>({ rank(it) }, { it }))
            val shown = when (grp) { "Избранное" -> ordered.filter { it.key in favs }; "Все" -> ordered; else -> channels.filter { it.group == grp }.sortedBy { it.name.lowercase() } }
            Row(Modifier.fillMaxHeight().padding(24.dp)) {
                Glass(Modifier.fillMaxHeight().width(230.dp)) {
                    LazyColumn { items(groups) { g -> Item(g == grp, { grp = g }) { Text(g, color = fg, fontSize = 16.sp, maxLines = 1) } } }
                }
                Spacer(Modifier.width(12.dp))
                Glass(Modifier.fillMaxHeight().width(440.dp)) {
                    LazyColumn {
                        items(shown) { c ->
                            Item(c == cur, { cur = c; panel = false }, {
                                saveFavs(if (c.key in favs) favs - c.key else favs + c.key)
                            }) {
                                AsyncImage(c.logo, null, Modifier.size(36.dp).padding(end = 10.dp))
                                Text(c.name, color = fg, fontSize = 16.sp, maxLines = 1, modifier = Modifier.weight(1f))
                                if (c.key in favs) Text("★", color = Color(0xFFFFD60A))
                            }
                        }
                    }
                }
            }
        }

        if (settings) Glass(Modifier.align(Alignment.Center).width(640.dp)) {
            Text("Настройки", color = fg, fontSize = 22.sp, modifier = Modifier.padding(8.dp))
            Row { listOf("auto" to "Авто", "light" to "Светлая", "dark" to "Тёмная").forEach { (k, n) ->
                Box(Modifier.weight(1f)) { Item(theme == k, { theme = k; sp.edit().putString("theme", k).apply() }) { Text(n, color = fg) } } } }
            Text("Плейлисты", color = fg, fontSize = 18.sp, modifier = Modifier.padding(8.dp))
            LazyColumn(Modifier.heightIn(max = 260.dp)) {
                items(presets) { (n, u) ->
                    Item(u in lists, { setLists(if (u in lists) lists - u else lists + u) }) { Text((if (u in lists) "✓  " else "     ") + n, color = fg) }
                }
                items(lists.filter { u -> presets.none { it.second == u } }) { u ->
                    Item(true, { setLists(lists - u) }) { Text("✕  $u", color = fg, maxLines = 1) }
                }
            }
            OutlinedTextField(custom, { custom = it }, label = { Text("Своя ссылка M3U") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Item(false, { if (custom.startsWith("http")) { setLists(lists + custom.trim()); custom = "" } }) { Text("Добавить ссылку", color = fg) }
            Item(false, { saveFavs(DEF_FAV.map { norm(it) }) }) { Text("Сбросить избранное", color = fg) }
            Item(false, { settings = false }) { Text("Закрыть", color = fg) }
        }
    }
}
